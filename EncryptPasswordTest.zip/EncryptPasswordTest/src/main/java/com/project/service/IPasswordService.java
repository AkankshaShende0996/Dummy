package com.project.service;

import com.project.bean.CustomerBean;


public interface IPasswordService {
public String encryptPassword(String password);
public CustomerBean loggedIn(String email,String password);
}
