 package com.project.service;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.project.bean.CustomerBean;
import com.project.repo.IPassworsRepository;

@Service
public class PasswordServiceImpl implements IPasswordService{
@Autowired
private IPassworsRepository repo;


	@Override
	@Transactional
	public String encryptPassword(String password) {
		StringBuilder sb=new StringBuilder(password);
		sb.reverse().append("$!").insert(0,"!$");
		System.out.println(sb);
		String encrytedPass=sb.toString();
		
		
/*		 String reverse = "";
	        
	        
	        for(int i = password.length() - 1; i >= 0; i--)
	        {
	        	reverse = reverse + password.charAt(i);
	        }
	      String encrytedPass ="!$" +reverse+"$!";*/
		
		System.out.println(encrytedPass);
		return encrytedPass;
		
		

	}


	@Override
	public CustomerBean loggedIn(String email, String password) {
		CustomerBean customer=new CustomerBean();
		customer.setEmail(email);
		customer.setPassword(encryptPassword(password));
		
		
		repo.saveAndFlush(customer);
		System.out.println(encryptPassword(password));
		return customer;

	}

}
